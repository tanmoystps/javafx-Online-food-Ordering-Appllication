/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eat;

/**
 *
 * @author tanmoy
 */
 class order1 {
     private String item_name,rest_name;
     private int quantity,total_price;
    public order1(String item_name,int quantity,int total_price,String rest_name)
    {
        this.item_name=item_name;
        this.quantity=quantity;
        this.total_price=total_price;
        this.rest_name=rest_name;
      
    }
    public String Item_name(){
        return item_name;
      
    }
    
    public int QUANTITY(){
        return quantity;
        
    }
    
    public int TOTAL_PRICE(){
        return total_price;
    }
    
    public String Rest_name(){
        return rest_name;
    }
    
   
}
