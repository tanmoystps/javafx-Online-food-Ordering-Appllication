/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eat;

/**
 *
 * @author tanmoy
 */
class user {
    private int Item_id,quantity,rate,subtotal;
    private String item_name;
    public user(int Item_id,String item_name,int quantity,int rate,int subtotal)
    {
        this.Item_id=Item_id;
        this.item_name=item_name;
        this.quantity=quantity;
        this.rate=rate;
        this.subtotal=subtotal;
    }
    public int ITEM_ID(){
        return Item_id;
      
    }
    
    public String ITEM_NAME(){
        return item_name;
        
    }
    
    public int quantity1(){
        return quantity;
    }
    
    public int rate1(){
        return rate;
    }
    
    public int subtotal(){
        return subtotal;
    }
}
