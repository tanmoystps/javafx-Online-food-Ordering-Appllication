/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eat;

/**
 *
 * @author tanmoy
 */
public class FIRST_SCREEN {
    public static void main(String args[]) {
        splash_screen ss=new splash_screen();
        ss.setVisible(true);
        try{
        for(int i=0;i<=100;i++)
        {
            Thread.sleep(100);
            ss.jLabel2.setText(Integer.toString(i)+"%");
            ss.jProgressBar1.setValue(i);
           if(i==100){
               
           ss.setVisible(false);
            home_page hp= null;
       
            hp = new home_page();
         hp.setVisible(true);
        hp.pack();
        hp.setLocationRelativeTo(null);
        hp.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
      //  this.dispose(); 
           }  
        }
        }catch(Exception e){
            
        }
    }

   
}
